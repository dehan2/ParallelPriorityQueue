#pragma once

#define NT 4

enum PPQ_COMMAND 
{PPQ_POP, PPQ_PUSH, PPQ_UPDATE, PPQ_EXIT};

const int INITIAL_HEAP_CAPACITY = 100;